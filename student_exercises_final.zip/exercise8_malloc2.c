
#include <stdio.h>
#include <stdlib.h>

int main() {
    int* ptr = (int*) malloc(sizeof(int));
   
    if (ptr == NULL) {
        printf("Memory allocation failed. Exiting.\n");
        return 1;
    }

    

    // TODO: Store a value to the new allocated memory
    // and Print the value stored at 'ptr'. Don't forget to free the allocated memory.

    return 0;
}
