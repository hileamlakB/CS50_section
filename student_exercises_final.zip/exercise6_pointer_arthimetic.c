
#include <stdio.h>

int main() {
    int int_var;
    char char_var;
    double double_var;

    int* int_ptr = &int_var;
    char* char_ptr = &char_var;
    double* double_ptr = &double_var;

    printf("Original address of int_ptr: %p\n", int_ptr);
    printf("Original address of char_ptr: %p\n", char_ptr);
    printf("Original address of double_ptr: %p\n", double_ptr);

    // TODO: Calculate and print the addresses of each pointer + 1.
    // What is the difference between each address? 
    // Can you spot a pattern?


    // TODO: What happens if you do +2, +3 ...
    // Write your answer before you try it out
    return 0;
}