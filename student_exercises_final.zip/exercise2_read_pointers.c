
#include <stdio.h>
#include "exercise.h"

  
int main() {
    // TODO: There is a secret pointer(address) called ptr_secret. It is an int address
    // can you print the secret inside it

    return 0;
}
