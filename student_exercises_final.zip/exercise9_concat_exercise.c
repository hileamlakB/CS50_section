#include <stdio.h>
#include <stdlib.h>

// Concatenate two arrays into a single array
int *concatarray(int *ar1, int *ar2, int ar1_sz, int ar2_sz) {
    // TODO: Implement the concatarray function
    return NULL;
}

int main(void) {
    int a1_sz = 10;
    int a2_sz = 20;

    int *a1 = malloc(sizeof(int) * a1_sz);
    int *a2 = malloc(sizeof(int) * a2_sz);

    // Sample values for testing (provided by instructor)
    for (int i = 0; i < a1_sz; i++) {
        a1[i] = i + 1;
    }
    for (int i = 0; i < a2_sz; i++) {
        a2[i] = a1_sz + i + 1;
    }

    int *concat = concatarray(a1, a2, a1_sz, a2_sz);

    // Check if the concat array contains the concatenated result
    int is_correct = 1;
    for (int i = 0; i < a1_sz + a2_sz; i++) {
        if (i < a1_sz && concat[i] != a1[i]) {
            is_correct = 0;
            break;
        } else if (i >= a1_sz && concat[i] != a2[i - a1_sz]) {
            is_correct = 0;
            break;
        }
    }

    if (is_correct) {
        printf("The concatenated array is correct!\n");
    } else {
        printf("There's a mismatch in the concatenated array.\n");
    }

    free(concat);
    free(a1);
    free(a2);

    return 0;
}
