
#include <stdio.h>
#include "exercise.h"


int main() {
    
    printf("Secret Value Before: %i\n", *ptr_secret);

    // TODO: Change the value of the secret variable
    // using the 'ptr_secret' to 61 and then print its new value.

    printf("Secret Value After: %i\n", *ptr_secret);
    return 0;
}
