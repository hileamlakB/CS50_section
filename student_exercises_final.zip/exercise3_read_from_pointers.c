
#include <stdio.h>

int main() {
    int var = 50;
    int* ptr = NULL;

    // TODO: Point 'ptr' to 'var' (i.e put var's addres as the value of ptr)
    // Can you print the value of 'var' using 'ptr'?

    return 0;
}
