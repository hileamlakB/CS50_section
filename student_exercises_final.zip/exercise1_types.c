
#include <stdio.h>

int main() {
    int var = 100;

    // TODO: Print the address of 'var' using printf.
    // HINT: Use %p to print addresses 
    return 0;
}
