#include <stdbool.h>
#include <stdio.h>

// TODO: write a program that takes a file, 
// and generates a new file that converts all 
// of the letters in the original file to uppercase.
int main(int argc, char *argv[])
{
    
}