extern int *ptr_secret;
