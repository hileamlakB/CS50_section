
#include <stdio.h>
#include <stdlib.h>

int main() {
    int* ptr = (int*) calloc(5, sizeof(int));
    if (!ptr) {
        printf("Memory allocation failed. Exiting.\n");
        return 1;
    }

    // TODO: Store values in the array and print them.
    // What do you observe about the initial values in a calloc'd array?

    free(ptr);
    return 0;
}
