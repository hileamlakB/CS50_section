
#include <stdio.h>
#include <stdlib.h>

int main() {
    int* ptr = (int*) malloc(sizeof(int));
    if (!ptr) {
        printf("Memory allocation failed. Exiting.\n");
        return 1;
    }

    *ptr = 42;
    printf("Value: %d\n", *ptr);

    // TODO: Free the allocated memory. Why is this step important?

    return 0;
}
