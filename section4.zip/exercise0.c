
#include <stdio.h>

int main() {
    int integer_var = 42;
    float float_var = 3.14;
    char char_var = 'A';

    // TODO: Print the values of the variables above using printf.
    // HINT: Use %d for int, %f for float, and %c for char.

    return 0;
}
